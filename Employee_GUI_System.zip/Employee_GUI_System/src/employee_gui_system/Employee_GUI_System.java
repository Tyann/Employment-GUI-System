/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee_gui_system;

/**
 *
 * @author YannErv
 */
public class Employee_GUI_System {

   

    public static void main(String[] args) {
       Login hw1 = new Login();
        
       //Menu mu = new Menu();
       /*System.out.println("Contents in employ file are as follows: ");
        db1.list();
*/
       //Register rg = new Register();
       //Search s = new Search();
       //List ls = new List();
    }//main
    
}//class

    

